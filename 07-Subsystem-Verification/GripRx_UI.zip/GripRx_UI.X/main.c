#include "mcc_generated_files/system/system.h"
#include <stdint.h>
#include <stdio.h>

// ==========================================================
// Sections 5.4 and 6: debug LED, button, and ribbon connector
// ==========================================================
static void run_sections_5_6(void)
{
    uint8_t ticks = 0;
    uint8_t level = 0;

    LATCbits.LATC2 = 0;  // J1 pin 2
    LATDbits.LATD0 = 0;  // J1 pin 3: UI_RUN

    while (1) {
        if (DBG_BTN_GetValue() == 0) {
            DBG_LED_SetHigh();
            printf("button pressed\r\n");
        } else {
            DBG_LED_Toggle();
        }

        __delay_ms(250);

        if (++ticks == 2) {
            ticks = 0;
            level ^= 1u;

            LATCbits.LATC2 = level;
            LATDbits.LATD0 = level;

            printf("J1 pin 1 = %u\r\n",
                   (unsigned int)PORTCbits.RC3);
        }
    }
}

// ==========================================================
// Section 7.1: read the four active-low buttons
// Each returned bit is 1 when its button is pressed.
// ==========================================================
#define SW1_MASK  0x01u
#define SW2_MASK  0x02u
#define SW3_MASK  0x04u
#define SW4_MASK  0x08u

static uint8_t read_buttons(void)
{
    uint8_t buttons = 0;

    if (PORTDbits.RD1 == 0) buttons |= SW1_MASK;  // START/STOP
    if (PORTDbits.RD2 == 0) buttons |= SW2_MASK;  // UP
    if (PORTDbits.RD3 == 0) buttons |= SW3_MASK;  // DOWN
    if (PORTBbits.RB3 == 0) buttons |= SW4_MASK;  // DEBUG

    return buttons;
}

// ==========================================================
// Section 7.3: delay for half of one square-wave period
// XC8 gets a constant delay value in each branch.
// ==========================================================
static void tone_half_period(uint16_t hz)
{
    switch (hz) {
        case 880:
            __delay_us(568);
            break;
        case 220:
            __delay_us(2273);
            break;
        default:                 // 440 Hz
            __delay_us(1136);
            break;
    }
}

// ==========================================================
// Section 7: button identification + audio output
// ==========================================================
static void run_section_7(void)
{
    uint16_t hz = 440;
    uint8_t previous = 0;

    // SW1 was held during reset to select this mode.
    // Release it before beginning the button test.
    while (PORTDbits.RD1 == 0) {
        __delay_ms(1);
    }
    __delay_ms(20);

    printf("Section 7 ready: 440 Hz\r\n");

    while (1) {
        uint8_t current = read_buttons();
        uint8_t pressed = current & (uint8_t)~previous;
        previous = current;

        // Report each new press rather than printing while held.
        if (pressed & SW1_MASK) {
            printf("SW1 START/STOP pressed\r\n");
        }

        if (pressed & SW2_MASK) {
            hz = 880;
            printf("SW2 UP pressed: 880 Hz\r\n");
        }

        if (pressed & SW3_MASK) {
            hz = 220;
            printf("SW3 DOWN pressed: 220 Hz\r\n");
        }

        if (pressed & SW4_MASK) {
            printf("SW4 DEBUG pressed\r\n");
        }

        // One square-wave cycle on DAC1 -> RA2 -> TP4.
        DAC1DATL = 255;
        tone_half_period(hz);

        DAC1DATL = 0;
        tone_half_period(hz);
    }
}

int main(void)
{
    SYSTEM_Initialize();

    if (PORTDbits.RD1 == 0) {
        run_section_7();      // Hold SW1 during reset: section 7
    } else {
        run_sections_5_6();   // Normal reset: sections 5.4 and 6
    }
}