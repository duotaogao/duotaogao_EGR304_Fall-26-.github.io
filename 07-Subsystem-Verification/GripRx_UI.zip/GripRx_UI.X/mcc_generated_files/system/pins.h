/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA2 aliases
#define IO_RA2_TRIS                 TRISAbits.TRISA2
#define IO_RA2_LAT                  LATAbits.LATA2
#define IO_RA2_PORT                 PORTAbits.RA2
#define IO_RA2_WPU                  WPUAbits.WPUA2
#define IO_RA2_OD                   ODCONAbits.ODCA2
#define IO_RA2_ANS                  ANSELAbits.ANSELA2
#define IO_RA2_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define IO_RA2_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define IO_RA2_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define IO_RA2_GetValue()           PORTAbits.RA2
#define IO_RA2_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define IO_RA2_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define IO_RA2_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define IO_RA2_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define IO_RA2_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define IO_RA2_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define IO_RA2_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define IO_RA2_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RB0 aliases
#define DBG_LED_TRIS                 TRISBbits.TRISB0
#define DBG_LED_LAT                  LATBbits.LATB0
#define DBG_LED_PORT                 PORTBbits.RB0
#define DBG_LED_WPU                  WPUBbits.WPUB0
#define DBG_LED_OD                   ODCONBbits.ODCB0
#define DBG_LED_ANS                  ANSELBbits.ANSELB0
#define DBG_LED_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define DBG_LED_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define DBG_LED_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define DBG_LED_GetValue()           PORTBbits.RB0
#define DBG_LED_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define DBG_LED_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define DBG_LED_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define DBG_LED_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define DBG_LED_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define DBG_LED_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define DBG_LED_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define DBG_LED_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set RB3 aliases
#define DBG_BTN_TRIS                 TRISBbits.TRISB3
#define DBG_BTN_LAT                  LATBbits.LATB3
#define DBG_BTN_PORT                 PORTBbits.RB3
#define DBG_BTN_WPU                  WPUBbits.WPUB3
#define DBG_BTN_OD                   ODCONBbits.ODCB3
#define DBG_BTN_ANS                  ANSELBbits.ANSELB3
#define DBG_BTN_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define DBG_BTN_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define DBG_BTN_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define DBG_BTN_GetValue()           PORTBbits.RB3
#define DBG_BTN_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define DBG_BTN_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define DBG_BTN_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define DBG_BTN_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define DBG_BTN_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define DBG_BTN_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define DBG_BTN_SetAnalogMode()      do { ANSELBbits.ANSELB3 = 1; } while(0)
#define DBG_BTN_SetDigitalMode()     do { ANSELBbits.ANSELB3 = 0; } while(0)

// get/set RC2 aliases
#define IO_RC2_TRIS                 TRISCbits.TRISC2
#define IO_RC2_LAT                  LATCbits.LATC2
#define IO_RC2_PORT                 PORTCbits.RC2
#define IO_RC2_WPU                  WPUCbits.WPUC2
#define IO_RC2_OD                   ODCONCbits.ODCC2
#define IO_RC2_ANS                  ANSELCbits.ANSELC2
#define IO_RC2_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define IO_RC2_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define IO_RC2_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define IO_RC2_GetValue()           PORTCbits.RC2
#define IO_RC2_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define IO_RC2_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define IO_RC2_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define IO_RC2_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define IO_RC2_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define IO_RC2_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define IO_RC2_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define IO_RC2_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set RC3 aliases
#define IO_RC3_TRIS                 TRISCbits.TRISC3
#define IO_RC3_LAT                  LATCbits.LATC3
#define IO_RC3_PORT                 PORTCbits.RC3
#define IO_RC3_WPU                  WPUCbits.WPUC3
#define IO_RC3_OD                   ODCONCbits.ODCC3
#define IO_RC3_ANS                  ANSELCbits.ANSELC3
#define IO_RC3_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define IO_RC3_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define IO_RC3_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define IO_RC3_GetValue()           PORTCbits.RC3
#define IO_RC3_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define IO_RC3_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define IO_RC3_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define IO_RC3_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define IO_RC3_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define IO_RC3_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define IO_RC3_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define IO_RC3_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RD0 aliases
#define UI_RUN_TRIS                 TRISDbits.TRISD0
#define UI_RUN_LAT                  LATDbits.LATD0
#define UI_RUN_PORT                 PORTDbits.RD0
#define UI_RUN_WPU                  WPUDbits.WPUD0
#define UI_RUN_OD                   ODCONDbits.ODCD0
#define UI_RUN_ANS                  ANSELDbits.ANSELD0
#define UI_RUN_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define UI_RUN_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define UI_RUN_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define UI_RUN_GetValue()           PORTDbits.RD0
#define UI_RUN_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define UI_RUN_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define UI_RUN_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define UI_RUN_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define UI_RUN_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define UI_RUN_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define UI_RUN_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define UI_RUN_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set RD1 aliases
#define BTN_START_TRIS                 TRISDbits.TRISD1
#define BTN_START_LAT                  LATDbits.LATD1
#define BTN_START_PORT                 PORTDbits.RD1
#define BTN_START_WPU                  WPUDbits.WPUD1
#define BTN_START_OD                   ODCONDbits.ODCD1
#define BTN_START_ANS                  ANSELDbits.ANSELD1
#define BTN_START_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define BTN_START_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define BTN_START_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define BTN_START_GetValue()           PORTDbits.RD1
#define BTN_START_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define BTN_START_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define BTN_START_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define BTN_START_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define BTN_START_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define BTN_START_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define BTN_START_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define BTN_START_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD2 aliases
#define BTN_UP_TRIS                 TRISDbits.TRISD2
#define BTN_UP_LAT                  LATDbits.LATD2
#define BTN_UP_PORT                 PORTDbits.RD2
#define BTN_UP_WPU                  WPUDbits.WPUD2
#define BTN_UP_OD                   ODCONDbits.ODCD2
#define BTN_UP_ANS                  ANSELDbits.ANSELD2
#define BTN_UP_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define BTN_UP_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define BTN_UP_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define BTN_UP_GetValue()           PORTDbits.RD2
#define BTN_UP_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define BTN_UP_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define BTN_UP_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define BTN_UP_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define BTN_UP_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define BTN_UP_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define BTN_UP_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define BTN_UP_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set RD3 aliases
#define BTN_DOWN_TRIS                 TRISDbits.TRISD3
#define BTN_DOWN_LAT                  LATDbits.LATD3
#define BTN_DOWN_PORT                 PORTDbits.RD3
#define BTN_DOWN_WPU                  WPUDbits.WPUD3
#define BTN_DOWN_OD                   ODCONDbits.ODCD3
#define BTN_DOWN_ANS                  ANSELDbits.ANSELD3
#define BTN_DOWN_SetHigh()            do { LATDbits.LATD3 = 1; } while(0)
#define BTN_DOWN_SetLow()             do { LATDbits.LATD3 = 0; } while(0)
#define BTN_DOWN_Toggle()             do { LATDbits.LATD3 = ~LATDbits.LATD3; } while(0)
#define BTN_DOWN_GetValue()           PORTDbits.RD3
#define BTN_DOWN_SetDigitalInput()    do { TRISDbits.TRISD3 = 1; } while(0)
#define BTN_DOWN_SetDigitalOutput()   do { TRISDbits.TRISD3 = 0; } while(0)
#define BTN_DOWN_SetPullup()          do { WPUDbits.WPUD3 = 1; } while(0)
#define BTN_DOWN_ResetPullup()        do { WPUDbits.WPUD3 = 0; } while(0)
#define BTN_DOWN_SetPushPull()        do { ODCONDbits.ODCD3 = 0; } while(0)
#define BTN_DOWN_SetOpenDrain()       do { ODCONDbits.ODCD3 = 1; } while(0)
#define BTN_DOWN_SetAnalogMode()      do { ANSELDbits.ANSELD3 = 1; } while(0)
#define BTN_DOWN_SetDigitalMode()     do { ANSELDbits.ANSELD3 = 0; } while(0)

// get/set RD4 aliases
#define LCD_D4_TRIS                 TRISDbits.TRISD4
#define LCD_D4_LAT                  LATDbits.LATD4
#define LCD_D4_PORT                 PORTDbits.RD4
#define LCD_D4_WPU                  WPUDbits.WPUD4
#define LCD_D4_OD                   ODCONDbits.ODCD4
#define LCD_D4_ANS                  ANSELDbits.ANSELD4
#define LCD_D4_SetHigh()            do { LATDbits.LATD4 = 1; } while(0)
#define LCD_D4_SetLow()             do { LATDbits.LATD4 = 0; } while(0)
#define LCD_D4_Toggle()             do { LATDbits.LATD4 = ~LATDbits.LATD4; } while(0)
#define LCD_D4_GetValue()           PORTDbits.RD4
#define LCD_D4_SetDigitalInput()    do { TRISDbits.TRISD4 = 1; } while(0)
#define LCD_D4_SetDigitalOutput()   do { TRISDbits.TRISD4 = 0; } while(0)
#define LCD_D4_SetPullup()          do { WPUDbits.WPUD4 = 1; } while(0)
#define LCD_D4_ResetPullup()        do { WPUDbits.WPUD4 = 0; } while(0)
#define LCD_D4_SetPushPull()        do { ODCONDbits.ODCD4 = 0; } while(0)
#define LCD_D4_SetOpenDrain()       do { ODCONDbits.ODCD4 = 1; } while(0)
#define LCD_D4_SetAnalogMode()      do { ANSELDbits.ANSELD4 = 1; } while(0)
#define LCD_D4_SetDigitalMode()     do { ANSELDbits.ANSELD4 = 0; } while(0)

// get/set RD5 aliases
#define LCD_D5_TRIS                 TRISDbits.TRISD5
#define LCD_D5_LAT                  LATDbits.LATD5
#define LCD_D5_PORT                 PORTDbits.RD5
#define LCD_D5_WPU                  WPUDbits.WPUD5
#define LCD_D5_OD                   ODCONDbits.ODCD5
#define LCD_D5_ANS                  ANSELDbits.ANSELD5
#define LCD_D5_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define LCD_D5_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define LCD_D5_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define LCD_D5_GetValue()           PORTDbits.RD5
#define LCD_D5_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define LCD_D5_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define LCD_D5_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define LCD_D5_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define LCD_D5_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define LCD_D5_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define LCD_D5_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define LCD_D5_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

// get/set RD6 aliases
#define LCD_D6_TRIS                 TRISDbits.TRISD6
#define LCD_D6_LAT                  LATDbits.LATD6
#define LCD_D6_PORT                 PORTDbits.RD6
#define LCD_D6_WPU                  WPUDbits.WPUD6
#define LCD_D6_OD                   ODCONDbits.ODCD6
#define LCD_D6_ANS                  ANSELDbits.ANSELD6
#define LCD_D6_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define LCD_D6_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define LCD_D6_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define LCD_D6_GetValue()           PORTDbits.RD6
#define LCD_D6_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define LCD_D6_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define LCD_D6_SetPullup()          do { WPUDbits.WPUD6 = 1; } while(0)
#define LCD_D6_ResetPullup()        do { WPUDbits.WPUD6 = 0; } while(0)
#define LCD_D6_SetPushPull()        do { ODCONDbits.ODCD6 = 0; } while(0)
#define LCD_D6_SetOpenDrain()       do { ODCONDbits.ODCD6 = 1; } while(0)
#define LCD_D6_SetAnalogMode()      do { ANSELDbits.ANSELD6 = 1; } while(0)
#define LCD_D6_SetDigitalMode()     do { ANSELDbits.ANSELD6 = 0; } while(0)

// get/set RD7 aliases
#define LCD_D7_TRIS                 TRISDbits.TRISD7
#define LCD_D7_LAT                  LATDbits.LATD7
#define LCD_D7_PORT                 PORTDbits.RD7
#define LCD_D7_WPU                  WPUDbits.WPUD7
#define LCD_D7_OD                   ODCONDbits.ODCD7
#define LCD_D7_ANS                  ANSELDbits.ANSELD7
#define LCD_D7_SetHigh()            do { LATDbits.LATD7 = 1; } while(0)
#define LCD_D7_SetLow()             do { LATDbits.LATD7 = 0; } while(0)
#define LCD_D7_Toggle()             do { LATDbits.LATD7 = ~LATDbits.LATD7; } while(0)
#define LCD_D7_GetValue()           PORTDbits.RD7
#define LCD_D7_SetDigitalInput()    do { TRISDbits.TRISD7 = 1; } while(0)
#define LCD_D7_SetDigitalOutput()   do { TRISDbits.TRISD7 = 0; } while(0)
#define LCD_D7_SetPullup()          do { WPUDbits.WPUD7 = 1; } while(0)
#define LCD_D7_ResetPullup()        do { WPUDbits.WPUD7 = 0; } while(0)
#define LCD_D7_SetPushPull()        do { ODCONDbits.ODCD7 = 0; } while(0)
#define LCD_D7_SetOpenDrain()       do { ODCONDbits.ODCD7 = 1; } while(0)
#define LCD_D7_SetAnalogMode()      do { ANSELDbits.ANSELD7 = 1; } while(0)
#define LCD_D7_SetDigitalMode()     do { ANSELDbits.ANSELD7 = 0; } while(0)

// get/set RE0 aliases
#define LCD_RS_TRIS                 TRISEbits.TRISE0
#define LCD_RS_LAT                  LATEbits.LATE0
#define LCD_RS_PORT                 PORTEbits.RE0
#define LCD_RS_WPU                  WPUEbits.WPUE0
#define LCD_RS_OD                   ODCONEbits.ODCE0
#define LCD_RS_ANS                  ANSELEbits.ANSELE0
#define LCD_RS_SetHigh()            do { LATEbits.LATE0 = 1; } while(0)
#define LCD_RS_SetLow()             do { LATEbits.LATE0 = 0; } while(0)
#define LCD_RS_Toggle()             do { LATEbits.LATE0 = ~LATEbits.LATE0; } while(0)
#define LCD_RS_GetValue()           PORTEbits.RE0
#define LCD_RS_SetDigitalInput()    do { TRISEbits.TRISE0 = 1; } while(0)
#define LCD_RS_SetDigitalOutput()   do { TRISEbits.TRISE0 = 0; } while(0)
#define LCD_RS_SetPullup()          do { WPUEbits.WPUE0 = 1; } while(0)
#define LCD_RS_ResetPullup()        do { WPUEbits.WPUE0 = 0; } while(0)
#define LCD_RS_SetPushPull()        do { ODCONEbits.ODCE0 = 0; } while(0)
#define LCD_RS_SetOpenDrain()       do { ODCONEbits.ODCE0 = 1; } while(0)
#define LCD_RS_SetAnalogMode()      do { ANSELEbits.ANSELE0 = 1; } while(0)
#define LCD_RS_SetDigitalMode()     do { ANSELEbits.ANSELE0 = 0; } while(0)

// get/set RE1 aliases
#define LCD_E_TRIS                 TRISEbits.TRISE1
#define LCD_E_LAT                  LATEbits.LATE1
#define LCD_E_PORT                 PORTEbits.RE1
#define LCD_E_WPU                  WPUEbits.WPUE1
#define LCD_E_OD                   ODCONEbits.ODCE1
#define LCD_E_ANS                  ANSELEbits.ANSELE1
#define LCD_E_SetHigh()            do { LATEbits.LATE1 = 1; } while(0)
#define LCD_E_SetLow()             do { LATEbits.LATE1 = 0; } while(0)
#define LCD_E_Toggle()             do { LATEbits.LATE1 = ~LATEbits.LATE1; } while(0)
#define LCD_E_GetValue()           PORTEbits.RE1
#define LCD_E_SetDigitalInput()    do { TRISEbits.TRISE1 = 1; } while(0)
#define LCD_E_SetDigitalOutput()   do { TRISEbits.TRISE1 = 0; } while(0)
#define LCD_E_SetPullup()          do { WPUEbits.WPUE1 = 1; } while(0)
#define LCD_E_ResetPullup()        do { WPUEbits.WPUE1 = 0; } while(0)
#define LCD_E_SetPushPull()        do { ODCONEbits.ODCE1 = 0; } while(0)
#define LCD_E_SetOpenDrain()       do { ODCONEbits.ODCE1 = 1; } while(0)
#define LCD_E_SetAnalogMode()      do { ANSELEbits.ANSELE1 = 1; } while(0)
#define LCD_E_SetDigitalMode()     do { ANSELEbits.ANSELE1 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/